﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FurnitureStore.Models
{
    public class Product
    {
        public static object FirstOrDefault { get; internal set; }
        [Key]
        public int ProductId { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string ImageUrl { get; set; }
        public string Description { get; set; }
        public string ImageThumbnail { get; set; }
        public bool Stock { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}
