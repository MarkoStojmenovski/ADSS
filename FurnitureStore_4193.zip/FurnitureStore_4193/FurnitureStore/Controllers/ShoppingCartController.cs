﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FurnitureStore.Data;
using FurnitureStore.Data.Interfaces;
using FurnitureStore.Models;
using FurnitureStore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FurnitureStore.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ShoppingCart _shoppingcart;

        public ShoppingCartController(IProductRepository productRepository, ShoppingCart shoppingCart)
        {
            _productRepository = productRepository;
            _shoppingcart = shoppingCart;
        }
        [Authorize]
        public ViewResult Index()
        {
            var items = _shoppingcart.GetShoppingCartItems();
            _shoppingcart.ShoppingCartItems = items;

            var sCVM = new ShoppingCartViewModel
            {
                ShoppingCart = _shoppingcart,
                ShoppingCartTotal = _shoppingcart.GetShoppingCartTotal()
            };
            return View(sCVM);
        }
        public RedirectToActionResult AddToShoppingCart(int productId)
        {
            var selectedProduct = _productRepository.Products.FirstOrDefault(p => p.ProductId == productId);
            if(selectedProduct!=null)
            {
                _shoppingcart.AddToCart(selectedProduct, 1);
            }
            return RedirectToAction("Index");
        }
        public RedirectToActionResult RemoveFromShoppingCart(int productId)
        {
            var selectedProduct = _productRepository.Products.FirstOrDefault(p =>p.ProductId == productId);
            if (selectedProduct != null)
            {
                _shoppingcart.RemoveFromCart(selectedProduct);
            }
            return RedirectToAction("Index");
        }
    }
}
