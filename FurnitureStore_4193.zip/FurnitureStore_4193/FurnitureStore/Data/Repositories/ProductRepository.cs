﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FurnitureStore.Data.Interfaces;
using FurnitureStore.Models;
using Microsoft.EntityFrameworkCore;

namespace FurnitureStore.Data.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;
        public ProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        public IEnumerable<Product> Products => _context.Product.Include(c => c.Category);

        public Product GetProductById(int productId) => _context.Product.FirstOrDefault(p => p.ProductId == productId);
    }
}
