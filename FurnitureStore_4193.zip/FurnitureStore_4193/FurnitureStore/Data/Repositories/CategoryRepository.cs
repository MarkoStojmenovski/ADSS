﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FurnitureStore.Data.Interfaces;
using FurnitureStore.Models;

namespace FurnitureStore.Data.Repositories
{
    public class CategoryRepository : ICategoryRpository
    {
        private readonly ApplicationDbContext _context;

        public CategoryRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        public IEnumerable<Category> Categories => _context.Category;
    }
}
