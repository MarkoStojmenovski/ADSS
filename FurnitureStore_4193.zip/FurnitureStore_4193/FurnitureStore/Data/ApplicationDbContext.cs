﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using FurnitureStore.Models;

namespace FurnitureStore.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
        public DbSet<FurnitureStore.Models.Category> Category { get; set; }
        public DbSet<FurnitureStore.Models.Product> Product { get; set; }
        public DbSet<FurnitureStore.Models.ShoppingCartItem> ShoppingCartItems { get; set; }
        public DbSet<FurnitureStore.Models.OrderDetail> OrderDetails { get; set; }
        public DbSet<FurnitureStore.Models.Order> Order { get; set; }
    }
}
